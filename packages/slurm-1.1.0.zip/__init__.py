"""Optional Slurm scheduler component."""
