"""BlendRL: neural and symbolic actors mixed by a learned blender."""

# Importing the agent registers the "blendrl"/"blender" model with the model registry.
from .agents import blender_agent  # noqa: F401
