"""Lightweight rules editing targets; no training imports."""
from pathlib import Path
import yaml


def rules_edit_targets(*, value, context):
    root = Path(context["workspace_root"])
    if not isinstance(value, str) or not value or Path(value).name != value:
        raise ValueError("Select one ruleset before editing its rules")
    config = context.get("config", {})
    environment = config.get("env", {})
    environment = environment if isinstance(environment, dict) else {"name": environment}
    name = environment.get("symbolic_name") or environment.get("name")
    if name:
        profile = root / "in/config/env" / f"{name}.yaml"
        if profile.is_file():
            declared = yaml.safe_load(profile.read_text()) or {}
            name = environment.get("symbolic_name") or declared.get("symbolic_name") or name
    rules_root = root / "in/rules"
    if name:
        directories = [rules_root / str(name) / value, rules_root / Path(str(name)).name / value]
    else:
        directories = sorted(rules_root.glob(f"*/{value}"))
    filename = "blender_clauses.txt" if "blender" in context.get("parameter_path", []) else "clauses.txt"
    targets = []
    seen = set()
    for directory in directories:
        target = (directory / filename).resolve()
        if not target.is_relative_to(rules_root.resolve()):
            raise ValueError("Rules path is outside this component's rules directory")
        if target.is_file() and target not in seen:
            seen.add(target)
            targets.append({"path": str(target), "label": str(target.relative_to(root))})
    if not targets:
        raise ValueError(f"No {filename} found for ruleset {value!r}")
    return targets
