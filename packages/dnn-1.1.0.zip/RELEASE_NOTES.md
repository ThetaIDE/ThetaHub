# DNN 1.1.0

shared_features=false provides independent policy/value feature networks; the default remains shared for checkpoint compatibility. All advertised activations are implemented and unknown activations are rejected.
