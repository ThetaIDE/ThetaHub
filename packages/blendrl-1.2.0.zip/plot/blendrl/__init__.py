"""BlendRL routing plotter."""
