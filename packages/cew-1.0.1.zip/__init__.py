"""CEW model module."""

# Importing the model registers "cew" with the model registry.
from . import cew_model  # noqa: F401
